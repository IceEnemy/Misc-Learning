public enum ClassStatus {
	Freshman,
	Sophomore,
	Junior,
	Senior
}
