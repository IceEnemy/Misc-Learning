
public class Duck extends Animals {

	public Duck() {
		super("Duck", 10);
		// TODO Auto-generated constructor stub
	}

	@Override
	void makeSound() {
		System.out.print("\"Kwek kwek kwek!\" ");;
	}

}
