
public class WildBoar extends Animals {

	public WildBoar() {
		super("Wild Boar", 30);
	}

	@Override
	void makeSound() {
		System.out.print("\"Ngeeq ngeeq!\" ");
	}

}
