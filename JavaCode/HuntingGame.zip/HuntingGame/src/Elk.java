
public class Elk extends Animals {

	public Elk() {
		super("Elk", 50);
		// TODO Auto-generated constructor stub
	}

	@Override
	void makeSound() {
		System.out.print("\"Eeeeelllkkk!\" ");

	}

}
